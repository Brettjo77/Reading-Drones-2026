# Reading Drones — CCB1 Logo Pack

The "Classic Comic Burst" logo for Reading Drones, rendered as live SVG + CSS so it scales cleanly to any size.

## Files

- **Reading Drones Logo.html** — open this in any browser to see the logo at multiple sizes (primary 680px, medium 480, small 320, favicon 200, dark-background variant, wordmark-only, tagline-only).
- **mavic-icon.jsx** — the Mavic 4 3/4-view drone icon component (`<MavicHero />`). Treatments: `comic`, `solid`, `line`, `silhouette`.
- **ccb-logo.jsx** — the logo composition: `<CCB1 />`, `<CCBWordmark />`, `<CCBTagline />`, `<SunburstRays />`.
- **page.jsx** — the showcase page itself; replace this when you start building real pages.

## Brand colors

| Role         | Hex       |
|--------------|-----------|
| Ink (outline) | `#0d0d10` |
| Cream (fill)  | `#f4ede1` |
| Yellow (burst bg) | `#fcd34d` |
| Orange (accent) | `#ef5a24` |
| Camera tint  | `#2aa7c8` |
| Status LED   | `#3fe07a` |

## Typography

- **Wordmark / tagline:** Archivo Black (Google Fonts) — heavy, geometric, holds up under the cream-fill / ink-stroke treatment.
- Body / nav copy is up to you when building the site; pair Archivo Black headlines with a clean neutral (e.g. Inter, Söhne, or system).

## Usage

Drop `<CCB1 width={500} height={500} />` anywhere on a React page after loading the three scripts in this order: `mavic-icon.jsx`, `ccb-logo.jsx`, your own page.

`<CCB1 />` accepts:
- `width` / `height` — pixel dimensions of the artboard
- `background` — defaults to cream
- `mavicSize`, `wordmarkSize`, `taglineSize` — manual scale overrides (otherwise auto from `height`)
- `showTagline` — hide the ribbon for very small sizes

## Starting the website project

When you create the new project, attach this whole `handoff/` folder. The new agent can read these files as the brand source of truth.
