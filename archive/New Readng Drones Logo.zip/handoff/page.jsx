// Showcase page that exercises the CCB1 lockup at multiple sizes/treatments.

const { CCB1, CCBWordmark, CCBTagline } = window;

function Card({ label, dark, children }) {
  return (
    <div className={`card${dark ? ' dark' : ''}`}>
      <div className="label">{label}</div>
      <div className="stage">{children}</div>
    </div>
  );
}

function Page() {
  return (
    <div className="page">
      <header>
        <h1>Reading Drones — Logo</h1>
        <p>The CCB1 mark in its primary form, plus alternate sizes and a dark-background treatment. All artwork is rendered as SVG/CSS so it stays sharp at any scale. Use as-is, or screenshot/export individual tiles for static assets.</p>
      </header>

      <section>
        <h2>Primary lockup · 680 × 680</h2>
        <div className="grid" style={{ gridTemplateColumns: '1fr' }}>
          <Card label="01 · Primary · cream background">
            <CCB1 width={680} height={680} />
          </Card>
        </div>
      </section>

      <section>
        <h2>Square sizes</h2>
        <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))' }}>
          <Card label="480 px · medium">
            <CCB1 width={480} height={480} />
          </Card>
          <Card label="320 px · small">
            <CCB1 width={320} height={320} />
          </Card>
          <Card label="200 px · favicon-ish">
            <CCB1 width={200} height={200} showTagline={false} />
          </Card>
        </div>
      </section>

      <section>
        <h2>Dark background variant</h2>
        <div className="grid" style={{ gridTemplateColumns: '1fr' }}>
          <Card label="On ink · same colors hold up" dark>
            <div style={{ padding: 40, display: 'flex', justifyContent: 'center' }}>
              <CCB1 width={620} height={620} />
            </div>
          </Card>
        </div>
      </section>

      <section>
        <h2>Wordmark only</h2>
        <div className="grid" style={{ gridTemplateColumns: '1fr' }}>
          <Card label="No burst · use over photography or busy backgrounds">
            <div style={{ padding: '60px 32px', display: 'flex', justifyContent: 'center', background: '#f4ede1', width: '100%' }}>
              <CCBWordmark size={92} />
            </div>
          </Card>
        </div>
      </section>

      <section>
        <h2>Tagline ribbon · standalone</h2>
        <div className="grid" style={{ gridTemplateColumns: '1fr' }}>
          <Card label="Use as a section accent or footer mark">
            <div style={{ padding: '40px 32px', display: 'flex', justifyContent: 'center', background: '#f4ede1', width: '100%' }}>
              <CCBTagline size={28} />
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Page />);
